int main() {

	int a;
	int b;
	int c;
	int d;
	int x;
	int y;
	int p;
	int q;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);
	
	x = 1;
	y = a*x;
	p = 3;
	x = 2;
	q = x + (b*p);
	z = 5;
	scanf("%d", &p);
	c = (x + (b + p)) + (z*a);
	d = 7;

	scanf("%d", &z);

	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", x);
	printf("%d\n", y);
	printf("%d\n", z);

	return 0;
}
