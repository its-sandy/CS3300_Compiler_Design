int main() {

    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int m;
    int n;
    int o;
    int i;

    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);
    scanf("%d", &d);
    scanf("%d", &e);

    f = 3;

    h = a * b;

    if ( (f * 5) <= 12) {
        h = (a * b) + c;
        a = c;
    } else {
        h = a * b;
    }

    h = a * b;
    scanf("%d", &i);
    g = c + (a*b);
    a = c;
    m = 256 * (a*b);

    printf("%d\n", h);
    printf("%d\n", a);
    printf("%d\n", g);
    printf("%d\n", m);

    return 0;
}
