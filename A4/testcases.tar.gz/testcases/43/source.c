int main() {

    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;

    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);
    scanf("%d", &d);
    scanf("%d", &e);


    h = 0;
    g = 0;
    f = 10;
    j = 0;

    d = (a * b);

    if ( ((a + b) * 4) > (8 * 5)) {
        e = (a * b);
        h = (a * b) * c;
    } else {
        j = (a * b);
    }
    k = (a * b);
    l = (a * b) * c;
    c = 4;
    m = (a * b) * c;
    i = (a * b) * (c+4);

    printf("%d\n", a);
    printf("%d\n", b);
    printf("%d\n", c);
    printf("%d\n", d);
    printf("%d\n", e);
    printf("%d\n", f);
    printf("%d\n", g);
    printf("%d\n", h);
    printf("%d\n", i);
    printf("%d\n", j);
    printf("%d\n", k);
    printf("%d\n", l);
    printf("%d\n", m);

    return 0;
}
