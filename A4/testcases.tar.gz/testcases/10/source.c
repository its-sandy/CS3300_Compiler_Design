int main() {

	int a;
	int b;
	int c;
	int d;
	int x;
	int y;
	int p;
	int q;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);
	c = (a + b) + ((a*b) * (2 * 4));
	z = (12 + (25*4)) + (25-9);
	x = (4 - 2);
	d = x*z;
	y = c*d;

	z = (a*b) + (a + b);

	p = (a + b) + (c*256);

	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", x);
	printf("%d\n", y);
	printf("%d\n", z);

	return 0;
}
