int main() {

	int a;
	int b;
	int c;
	int d;
	int x;
	int y;
	int p;
	int q;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);
	
	x = 1;
	y = 2;
	p = 3;
	q = 4;
	z = 5;
	c = 6;
	d = 7;

	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", x);
	printf("%d\n", y);
	printf("%d\n", z);

	return 0;
}
