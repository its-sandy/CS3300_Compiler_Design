int main() {

    int b;
    int c;

    scanf("%d", &b);
    scanf("%d", &c);

    if ((b + c) > 30 ) {
        printf("%d\n", b);
    } else {
        printf("%d\n", c);
    }

    return 0;
}
