int main() {
	int tarzan;
	int terk;
	int tantor;
	int kerchak;
	int archimedes;
 	tarzan = 106;
	terk = tarzan % 6;
	tantor = tarzan % 2;
	kerchak = terk + tantor;
	archimedes = kerchak / 2;
	archimedes = archimedes + 23;
	printf("%d\n", archimedes);
	return 0;
}
