int main() {
	int a;
	int b;
	int c;
	a = (1054);
	b = (1064);

	while ((a != b)) {
		printf("%d\n", a);
		a = (a + 1);
	}
	return 0;
}
