int main() {
	int a[4];
	int b;
	a[0] = 4;
	a[1] = 3;
	a[2] = 2;
	a[3] = 0;
	b = a[0];
	printf("%d\n", b);
	b = a[1];
	printf("%d\n", b);
	b = a[2];
	printf("%d\n", b);
	b = a[3];
	printf("%d\n", b);
}
