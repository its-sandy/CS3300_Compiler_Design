int main() {
	int a;
	int b;
	int c;
	a = 6;
	b = 24;
	c = a > b;
	if (c)
		printf("%d\n", a);
	return 0;
}
