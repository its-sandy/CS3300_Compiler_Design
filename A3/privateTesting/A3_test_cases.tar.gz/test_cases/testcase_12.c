int main() {
	int a;
	a = -6;
	a = -a;
	printf("%d\n", a);
	return 0;
}
