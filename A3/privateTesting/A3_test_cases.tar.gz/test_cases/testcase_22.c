int main() {
	int a; 
	int b;
	b = 15;
	a = b * 6;
	printf("%d\n", a);
	return 0;
}
