int main() {
	int nobita;
	int shizuka;
	int gian;
	int suneo;
 	nobita = 32;
	shizuka = 72;
	gian = nobita != shizuka;
	suneo = gian || 0;
	printf("%d\n", suneo);
	return 0;
}
