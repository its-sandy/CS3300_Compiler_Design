int main() {
	int a;
	a = 995;
	if (1) 
		printf("%d\n", a);
	return 0;
}
