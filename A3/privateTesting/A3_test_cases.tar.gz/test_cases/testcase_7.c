int main() {
	int a; 
	int b;
	int c;
	int d;
	int e;
	int f;
	a = 72;
	b = 18;
	c = 1;
	d = a != b;
	e = c && d;
	f = !e;
	a = f;
	printf("%d\n", a);
	return 0;
}
