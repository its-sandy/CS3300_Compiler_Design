int main() {
	int a;
	int b;
	a = 6;
	b = 9;
	while (b >= 1) {
		printf("%d\n", a);
		b = b - 1;
	}
}
