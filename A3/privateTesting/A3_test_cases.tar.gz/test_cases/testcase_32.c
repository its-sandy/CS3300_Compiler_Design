int main() {
	int a; 
	int b;
	b = 15;
	a = (a);
	printf("%d\n", a);
	return 0;
}
