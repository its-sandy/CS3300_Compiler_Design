int main() {
	if (1) {
		int a;
		a = 150;
		printf("%d\n", a);
	}
	return 0;
}
