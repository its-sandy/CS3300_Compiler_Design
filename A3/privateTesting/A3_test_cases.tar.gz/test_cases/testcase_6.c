int main() {
	int a;
	a = 6;
	while (a >= 1) {
		int c;
		c = a;
		printf("%d\n", a);
		a = c - 1;
	}
}
