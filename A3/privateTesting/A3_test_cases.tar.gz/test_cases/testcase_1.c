int main() {
	int a;
	a = 6;
	printf("%d\n", a);
	return 0;
}
