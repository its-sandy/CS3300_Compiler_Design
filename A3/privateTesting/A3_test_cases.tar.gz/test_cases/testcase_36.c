int main() {
	int a;
	int b;
	a = 995;
	b = 1064;
	if (0) 
		printf("%d\n", a);
	else 
		printf("%d\n", b);
	if (1) 
		printf("%d\n", a);
	else 
		printf("%d\n", b);
	return 0;
}
