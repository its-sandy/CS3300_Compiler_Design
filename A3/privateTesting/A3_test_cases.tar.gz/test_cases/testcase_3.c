int main() {
	int a;
	int b;
	int c;
	a = 33;
	c = 15;
	printf("%d\n", a);
	b = c;
	printf("%d\n", b);
	return 0;
}
