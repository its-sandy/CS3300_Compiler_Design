int main() {
	int a;
	int b;
	int c;
	a = -6;
	b = 7;
	c = a - b;
	printf("%d\n", c);
	return 0;
}
