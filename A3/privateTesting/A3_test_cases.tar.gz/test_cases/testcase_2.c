int main() {
	int a; 
	int b;
	b = 0;
	a = b - 6;
	printf("%d\n", a);
	return 0;
}
