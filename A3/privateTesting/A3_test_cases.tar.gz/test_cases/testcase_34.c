int main() {
	if (1) {
		int a;
		a = 150;
		printf("%d\n", a);
	}
	else {
		int b;
		b = 250;
		printf("%d\n", b);
	}

	if (0) {
		int c;
		c = 150;
		printf("%d\n", c);
	}
	else {
		int d;
		d = 250;
		printf("%d\n", d);
	}
	return 0;
}
