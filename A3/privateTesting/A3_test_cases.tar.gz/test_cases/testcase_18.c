int main() {
	int tBone;
	int razor;
	int viper;
	viper = (-67) > 67;
	razor = 66 >= 66;
	tBone = viper || razor;
	tBone = !tBone;
	tBone = tBone + 91;
	printf("%d\n", tBone);
}
