int main() {
	int a; 
	int b;
	int c;
	b = 96;
	a = 65;
	c = a == b;
	printf("%d\n", c);
	a = 96;
	c = a == b;
	printf("%d\n", c);
	return 0;
}
